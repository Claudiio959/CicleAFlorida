package yoa.pmdm.claudio.ciclesaflorida;

import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements TipusCicle.comunicaTipoCiclo,Titulaciones.comunicaTitulacion, Llistat.OnFragmentInteractionListener{
    FragmentManager fm;
    FragmentTransaction ft;
    Fragment fragmentArriba;
    Fragment fragmentCentro;
    Fragment fragmentAbajo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fm = getSupportFragmentManager();
        fragmentCentro = TipusCicle.newInstance(false,false);
        fragmentAbajo = Llistat.newInstance("","");
        fragmentArriba = (Titulaciones) fm.findFragmentById(R.id.fragment);

        ft= fm.beginTransaction();

        ft.add(R.id.fmedio,fragmentCentro);
        ft.add(R.id.fabajo,fragmentAbajo);

        ft.commit();
    }

    @Override
    public void tipoCicloPulsado(int id) {

    }

    @Override
    public void titulacionPulsada(int id) {

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
